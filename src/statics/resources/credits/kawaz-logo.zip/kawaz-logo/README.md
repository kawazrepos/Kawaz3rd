# Kawazロゴ画像

制作物に利用できるKawazロゴの素材です。

以下の形式のファイルが含まれています

- png
- svg
- Adobe Illustrator

詳しい使い方については下記ページを参照してください

http://www.kawaz.org/guideline/credits/
