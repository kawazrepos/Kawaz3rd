# Kawazロゴ画像

制作物に利用できるKawaz動画ロゴの素材です。	
形式はMP4、音声の差し替え、改変、音のみの使用は可能とします。


詳しい使い方については下記ページを参照してください

http://www.kawaz.org/guideline/credits/